package Gui;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import Class.ProductType;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class CartGui extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField shoppingSummaryTextField;
	private JTextField creditCardTextField;
	private JTextField cvsNumTextField;
	private static double totalSum;
	private DecimalFormat formatprice = new DecimalFormat("#0.00");
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CartGui frame = new CartGui(null, totalSum);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param totalSum 
	 * @param totalcost 
	 */
	public CartGui(ArrayList<ProductType> products, double totalSum) {
		setTitle("Cart");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 514, 282);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(2, 0, 0, 0));
		
		JPanel summaryTextArea = new JPanel();
		summaryTextArea.setBorder(new TitledBorder(null, "Shopping Summary", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		contentPane.add(summaryTextArea);
		summaryTextArea.setLayout(new BorderLayout(0, 0));
		
		shoppingSummaryTextField = new JTextField();
		shoppingSummaryTextField.setText("The total is\n" + products.toString() + "\nTotal :" + formatprice.format(totalSum));
		summaryTextArea.add(shoppingSummaryTextField);
		shoppingSummaryTextField.setColumns(10);
		
		JPanel checkOutPanel = new JPanel();
		contentPane.add(checkOutPanel);
		checkOutPanel.setLayout(new GridLayout(2, 2, 0, 0));
		
		JPanel creditCardInfoPanel = new JPanel();
		checkOutPanel.add(creditCardInfoPanel);
		creditCardInfoPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel creditCardLabel = new JLabel("Credit Card Number");
		creditCardInfoPanel.add(creditCardLabel);
		
		creditCardTextField = new JTextField();
		creditCardInfoPanel.add(creditCardTextField);
		creditCardTextField.setColumns(17);
		
		JLabel cvsNumLabel = new JLabel("CVS");
		creditCardInfoPanel.add(cvsNumLabel);
		
		cvsNumTextField = new JTextField();
		creditCardInfoPanel.add(cvsNumTextField);
		cvsNumTextField.setColumns(10);
		
		JPanel buttonPanel = new JPanel();
		checkOutPanel.add(buttonPanel);
		
		JButton checkOutButton = new JButton("Check Out");
		buttonPanel.add(checkOutButton);
		
		JButton shopButton = new JButton("Continue Shopping");
		buttonPanel.add(shopButton);
		shopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ProductsGui().setVisible(true);
				dispose();
			}
		});
		checkOutButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String credit= creditCardTextField.getText();
				String cvsNum = cvsNumTextField.getText();
				if (credit.length() == 16 && cvsNum.length()== 3) {
					JOptionPane.showMessageDialog(null, "Succesfull purcharse!");
					shoppingSummaryTextField.setText(null);
				}
				else if (credit.length() == 13 && cvsNum.length()== 3) {
					JOptionPane.showMessageDialog(null, "Succesfull purcharse!");
					shoppingSummaryTextField.setText(null);
				}else {
					JOptionPane.showMessageDialog(null, "Wrong card number!");
				}
			}
		});
	}

}
