package Final.Project;

public class Driver {

	public static void main(String[] args) {
		Order order1 = new Order(0);
		System.out.println(Order.numberGenerator(1,1000));
		System.out.println(Order.getOrderNumber());

	}

}
