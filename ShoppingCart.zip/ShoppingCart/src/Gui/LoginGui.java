/*
 * Program description : 
 * This class will take the info (price and quantity and name)gotten from the other classes of product.
 * This class also calculate the total cost of the cart. It returns all info.
 * There is also methods that will compare the product so they can be sorted according to the 
 * user option in the GUI.
 * Author: Geu THAO, Haley Roy, Samuel Xiong
 * Assignment: Final Project
 * Instructor : Zakaria Baani
 * Date: May, 6 2020
 * Class: CSCI 1082 
 */
package Gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.border.TitledBorder;

import Class.CustomerAccountClass;
import Class.CustomerLogin;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;


public class LoginGui extends JFrame {

	private static final long serialVersionUID = 1L;
	//variable and element that needs to be accessible by the whole gui
	private JPanel contentPane;
	private JTextField loginField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			//create an object gui
			public void run() {
				try {
					LoginGui frame = new LoginGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	//login interface
	public LoginGui() {
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 469, 194);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		//panel for the login
		JPanel loginPanel = new JPanel();
		loginPanel.setBorder(new TitledBorder(null, "Login", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		contentPane.add(loginPanel, BorderLayout.NORTH);
		loginPanel.setLayout(new GridLayout(2, 2, 0, 10));

		//login label and textfield 
		JLabel login = new JLabel("Login");
		login.setFont(new Font("Times New Roman", Font.BOLD, 14));
		login.setVerticalAlignment(SwingConstants.CENTER);
		loginPanel.add(login);

		loginField = new JTextField();
		loginField.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		loginPanel.add(loginField);
		loginField.setColumns(10);

		//password label and textfield 
		JLabel lblNewLabel = new JLabel("Password");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 15));
		loginPanel.add(lblNewLabel);

		passwordField = new JPasswordField();
		loginPanel.add(passwordField);

		JPanel optionPanel = new JPanel();
		optionPanel.setBorder(null);
		contentPane.add(optionPanel, BorderLayout.CENTER);
		optionPanel.setLayout(new GridLayout(0, 1, 0, 0));

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Options", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		optionPanel.add(panel);

		JButton Login = new JButton("Login");
		panel.add(Login);

		//button that will take the user to the create account interface
		JButton createNewAccount = new JButton("Create New Account");
		createNewAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateNewAccountGui newFrame = new CreateNewAccountGui();
				newFrame.setVisible(true);
				dispose();
			}
		});
		panel.add(createNewAccount);
		//login action when login button is clicked on
		Login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//get the datafile and the password and login
				String log = loginField.getText();
				String psw = String.valueOf(passwordField.getPassword());
				
				//check if the field are empty
				if (log.equals("") || psw.equals("")) {
					JOptionPane.showMessageDialog(null, "No username or password entered.");
				} else {
					try {
						//if not empty, open the document and check if the user is present in the datafile
						BufferedReader selectedDocument = new BufferedReader(new FileReader("src/customer.csv"));
						String line;
						//read each line and take the data to check in the object customer
						while ((line = selectedDocument.readLine()) != null) {
							String[] data = line.split(",");
							String firstName = data[0];
							String lastName = data[1];
							String address = data[2];
							String username = data[3];
							String password = data[4];

							// first check if username and password match
							if (log.equals(username)) {
								if (psw.equals(password)) {
									JOptionPane.showMessageDialog(null, "Succesful login.");
									// make a cusomerInfo object
									CustomerLogin logInformation = new CustomerLogin(username, password);
									CustomerAccountClass customerInfo = new CustomerAccountClass(firstName, lastName,
											address, logInformation);
									//transfer the data to the next gui
									CustomerInfoGui frame = new CustomerInfoGui(customerInfo);
									frame.setVisible(true);
									dispose();
									
								} else {
									JOptionPane.showMessageDialog(null, "Wrong password or username.");
								}
							}else{
								JOptionPane.showMessageDialog(null, "Wrong password or username.");
							}
							}selectedDocument.close();
					} catch (IOException e1) {
						
						JOptionPane.showMessageDialog(null, "Error!");
					}
					
				}

			}

		});
	}

}
