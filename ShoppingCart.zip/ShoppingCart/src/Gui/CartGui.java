/*
 * Program description : 
 * This class will create a gui for the checkout interface and user can check out and get an order
 * number when the user enter valid credit card and csv number
 * Author: Geu THAO, Haley Roy, Samuel Xiong
 * Assignment: Final Project
 * Instructor : Zakaria Baani
 * Date: May, 6 2020
 * Class: CSCI 1082 
 */
package Gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import Class.CustomerAccountClass;
import Class.OrderId;


import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class CartGui extends JFrame {

	private static final long serialVersionUID = 1L;
	
	//variable that need to be accessed by the whole gui
	private JPanel contentPane;
	private JTextField creditCardTextField;
	private JTextField cvsNumTextField;
	private static double totalSum;
	private DecimalFormat formatprice = new DecimalFormat("#0.00");
	private Date actualDate = new Date();
	private JScrollPane scrollBar;
	private long packageNumber = 100000000L + new Random().nextInt(900000000);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			//create a frame
			public void run() {
				try {
					CartGui frame = new CartGui(null, totalSum, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @param totalSum
	 * @param customerInfo
	 * @param totalcost
	 */
	//checkout gui that call the info of orderId, customerAccountclass and totalsum
	public CartGui(OrderId orderNum, double totalSum, CustomerAccountClass customerInfo) {
		setTitle("Cart");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 514, 282);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(2, 0, 0, 0));
		
		//panel for the display cart items area 
		JPanel summaryTextArea = new JPanel();
		summaryTextArea.setBorder(
				new TitledBorder(null, "Shopping Summary", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		contentPane.add(summaryTextArea);
		summaryTextArea.setLayout(new BorderLayout(0, 0));

		//return the cart info
		JTextArea shoppingSummaryTextArea = new JTextArea();
		shoppingSummaryTextArea.append("\nThe order summary :" + orderNum.toString() + "\nDate : " + actualDate
				+ "\nTotal :" + formatprice.format(totalSum));
		scrollBar = new JScrollPane(shoppingSummaryTextArea);
		summaryTextArea.add(scrollBar, BorderLayout.CENTER);
		
		//checkout panel
		JPanel checkOutPanel = new JPanel();
		contentPane.add(checkOutPanel);
		checkOutPanel.setLayout(new GridLayout(2, 2, 0, 0));

		//credit card and csv label and textfield
		JPanel creditCardInfoPanel = new JPanel();
		checkOutPanel.add(creditCardInfoPanel);
		creditCardInfoPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		JLabel creditCardLabel = new JLabel("Credit Card Number\r\n");
		creditCardInfoPanel.add(creditCardLabel);

		creditCardTextField = new JTextField();
		creditCardInfoPanel.add(creditCardTextField);
		creditCardTextField.setColumns(17);

		JLabel cvsNumLabel = new JLabel("CVS");
		creditCardInfoPanel.add(cvsNumLabel);

		cvsNumTextField = new JTextField();
		creditCardInfoPanel.add(cvsNumTextField);
		cvsNumTextField.setColumns(10);

		//button panel
		JPanel buttonPanel = new JPanel();
		checkOutPanel.add(buttonPanel);

		JButton checkOutButton = new JButton("Check Out");
		buttonPanel.add(checkOutButton);

		JButton shopButton = new JButton("Continue Shopping");
		buttonPanel.add(shopButton);

		JButton exitButton = new JButton("Exit");
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//if the button called is exit, exit from the program
				dispose();
			}
		});

		JButton profileButton = new JButton("Go Back To Profile");
		profileButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*if the button called is go back to profile, call the info from the customer 
				 * and go back to the customer information interface* */
				CustomerInfoGui infoGui = new CustomerInfoGui(customerInfo);
				infoGui.setVisible(true);
				dispose();
			}
		});
		buttonPanel.add(profileButton);
		buttonPanel.add(exitButton);
		shopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*if the button called is shop more, call the info from the customer and go back to
				 the shoppingcart interface* */
				new ProductsGui(customerInfo, orderNum).setVisible(true);
				dispose();
			}
		});
		checkOutButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//get the credit card and cvs info
				String credit = creditCardTextField.getText();
				String cvsNum = cvsNumTextField.getText();
				if (credit.length() == 16 && cvsNum.length() == 3) {
					//if condition is met, create a package number and display a message
					JOptionPane.showMessageDialog(null,
							"Succesfull purcharse!\n Your package number is :" + packageNumber);
					FileWriter newFile;
					try {
						//if condition is met, create a cart for the customer into his own database  
						newFile = new FileWriter(customerInfo.getFirstName() + "cart.csv");
						if (orderNum.toString() != null) {
							newFile.append(orderNum.toString()+ ",\nPackage Number :" + 
									packageNumber +"\nDate: "+ actualDate + "\n");
							
						}
						
						newFile.close();
						shoppingSummaryTextArea.setText(null);
					} catch (IOException e1) {

						shoppingSummaryTextArea.setText("Error");
					}

				} else if (credit.length() == 13 && cvsNum.length() == 3) {
					//if condition is met, create a cart for the customer into his own database  
					JOptionPane.showMessageDialog(null,
							"Succesfull purcharse!\n Your package number is :" + packageNumber);
					FileWriter newFile;
					try {
						//if condition is met, create a cart for the customer into his own database  
						newFile = new FileWriter(customerInfo.getFirstName() + "cart.csv");
						if (orderNum.toString() != null) {
							newFile.append(orderNum.toString()+ ",\nPackage Number :" + 
									packageNumber +"\nDate: "+ actualDate);
						}
						newFile.close();
						shoppingSummaryTextArea.setText(null);
					} catch (IOException e1) {
						//if not display error
						shoppingSummaryTextArea.setText("Error");
					}
				} else {
					//if not display error
					JOptionPane.showMessageDialog(null, "Wrong card number!");
				}
			}
		});
	}

}
