/*
 * Program description : 
 * This class create a gui for the product list
 * Author: Geu THAO, Haley Roy, Samuel Xiong
 * Assignment: Final Project
 * Instructor : Zakaria Baani
 * Date: May, 6 2020
 * Class: CSCI 1082 
 */
package Gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

import Class.CustomerAccountClass;
import Class.Electronics;
import Class.KitchenAndDining;
import Class.OrderId;
import Class.PersonalCareCategory;
import Class.ProductType;

import java.awt.SystemColor;

public class ProductsGui extends JFrame {

	private static final long serialVersionUID = 1L;
	
	//variables that need to be reached by the whole gui
	private JPanel contentPane;
	private JTextField quantityTextField;
	private ArrayList<ProductType> products = new ArrayList<>();
	private JComboBox<Object> productCategories;
	private JTextArea outputArea;
	private JComboBox<Object> productType;
	private JLabel priceLabel;
	private JScrollPane scroll;
	private double totalSum;
	JFileChooser chooser = new JFileChooser("src/customerCart.csv");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProductsGui frame = new ProductsGui(null, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @param customerInfo
	 * @param orderNum 
	 * @param customeraccountclass
	 */
	//product gui frame and call the customerInfo
	public ProductsGui(CustomerAccountClass customerInfo, OrderId orderNum) {
		setTitle("Cart");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 425);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(2, 1, 0, 0));
		
		//panel for the product info 
		JPanel mainPanel = new JPanel();
		contentPane.add(mainPanel);
		mainPanel.setLayout(new BorderLayout(0, 0));
		
		//button panel for the button
		JPanel buttonPanel = new JPanel();
		mainPanel.add(buttonPanel, BorderLayout.SOUTH);

		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//if button add is clicked, get all data
				String type;
				String name;
				double price;
				int qty;
				try {
					type = (String) productCategories.getSelectedItem();
					name = (String) productType.getSelectedItem();
					price = Double.parseDouble(priceLabel.getText());
					
					//check no data error and create new objects and add it to the array
					qty = Integer.parseInt(quantityTextField.getText());
					if (type.equalsIgnoreCase("Personal Care Category")) {
						ProductType personalCare = new PersonalCareCategory(name, price, qty);
						products.add(personalCare);
						outputArea.append("Product added\n");
					} else if (type.equalsIgnoreCase("Electronics")) {
						ProductType ElectronicsKind = new Electronics(name, price, qty);
						products.add(ElectronicsKind);
						outputArea.append("Product added\n");
					} else if (type.equalsIgnoreCase("Kitchen And Dining")) {
						ProductType kitchenware = new KitchenAndDining(name, price, qty);
						products.add(kitchenware);
						outputArea.append("Product added\n");
					}
					for (int i = 0; i < products.size(); i++)

					{
						//get item and calculate the total
						ProductType item = products.get(i);
						totalSum += item.getPrice() * item.getQty();
					}

				} catch (Exception e2) {
					//if the number is not entered
					outputArea.append("You didn't enter the right format of quantity! "
							+ "Or you didn't select any category\n");
				}

			}
		});
		buttonPanel.add(btnAdd);

		JButton btnDisplay = new JButton("Go to Cart Summary");
		btnDisplay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//take to the checkout area when Go to Cart Summary 
				OrderId orderNum = new OrderId(products);
				new CartGui(orderNum, totalSum, customerInfo).setVisible(true);
				dispose();
			}
		});

		JButton displayButton = new JButton("Display Cart");
		displayButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//display cart display all the cart content
				outputArea.append(products.toString() + "\n");
			}
		});
		
				JButton removeButton = new JButton("Remove Item");
				buttonPanel.add(removeButton);
				removeButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						//get all data
						String type;
						String name;
						double price;

						int qty;
						ProductType itemToRemove = null;
						try {
							type = (String) productCategories.getSelectedItem();
							name = (String) productType.getSelectedItem();
							price = Double.parseDouble(priceLabel.getText());
							//check there is no empty variable
							qty = Integer.parseInt(quantityTextField.getText());
							if (type.equalsIgnoreCase("Personal Care Category")) {
								itemToRemove = new PersonalCareCategory(name, price, qty);
								//if item is not in the cart
								if(!products.contains(itemToRemove)) {
									outputArea.append("\n" + name + " not in cart!\n");
									return;
								}
							} else if (type.equalsIgnoreCase("Electronics")) {
								//if item is in cart, remove it
								itemToRemove = new Electronics(name, price, qty);
								if(!products.contains(itemToRemove)) {
									outputArea.append("\n" + name + " not in cart!\n");
									return;
								}
							} else if (type.equalsIgnoreCase("Electronics")) {
								itemToRemove = new Electronics(name, price, qty);
								if(!products.contains(itemToRemove)) {
									outputArea.append("\n" + name + " not in cart!\n");
									return;
								}
								
							}
							products.remove(itemToRemove);
							outputArea.append("\n" + name + " was removed!\n");

						} catch (NumberFormatException e1) {
							//catch error if the number is wrong
							outputArea.append("You didn't enter a valable number for the quantity!\n");
						}

					}

				});
		buttonPanel.add(displayButton);
		buttonPanel.add(btnDisplay);

		JPanel productPanel = new JPanel();
		productPanel.setBorder(new TitledBorder(null, "Products", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		mainPanel.add(productPanel, BorderLayout.CENTER);
		productPanel.setLayout(new GridLayout(0, 4, 0, 30));

		JLabel productName = new JLabel("Product");
		productName.setHorizontalAlignment(SwingConstants.CENTER);
		productPanel.add(productName);

		productCategories = new JComboBox<Object>();
		//product main categories
		productCategories.setModel((ComboBoxModel<Object>) new DefaultComboBoxModel<Object>(
				new String[] { "Select", "Electronics", "Personal Care Category", "Kitchen and Dining" }));
		productCategories.setBackground(Color.WHITE);
		productPanel.add(productCategories);

		JButton productTypeButton = new JButton("Select");
		productTypeButton.addActionListener(new ActionListener() {
			//when main categorie is selected, display sub-categories
			public void actionPerformed(ActionEvent e) {
				String productCategory = (String) productCategories.getSelectedItem();
				if (productCategory.equalsIgnoreCase("Personal Care Category")) {
					productType.setModel(
							new DefaultComboBoxModel<Object>(new String[] { "Select", "Shampoo", "Hand Cream" }));
				}
				if (productCategory.equalsIgnoreCase("Electronics")) {
					productType.setModel(new DefaultComboBoxModel<Object>(new String[] { "Select", "MAC", "ASUS" }));
				}
				if (productCategory.equalsIgnoreCase("Kitchen and Dining")) {
					productType.setModel(new DefaultComboBoxModel<Object>(new String[] { "Select", "Fork", "Spoon" }));
				}
			}
		});
		productPanel.add(productTypeButton);

		JLabel lblNewLabel_2 = new JLabel("");
		productPanel.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Name");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		productPanel.add(lblNewLabel_3);

		productType = new JComboBox<Object>();
		productType.setBackground(Color.WHITE);
		productPanel.add(productType);

		JButton selectButton = new JButton("Select");
		selectButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//when product is selected, price appear at the price area
				try {
				String name = (String) productType.getSelectedItem();
				if (name.equalsIgnoreCase("Mac")) {
					priceLabel.setText("729.79");
				} else if (name.equalsIgnoreCase("Asus")) {
					priceLabel.setText("879.99");
				} else if (name.equalsIgnoreCase("Hand Cream")) {
					priceLabel.setText("3.70");
				} else if (name.equalsIgnoreCase("Shampoo")) {
					priceLabel.setText("10.40");
				} else if (name.equalsIgnoreCase("Fork")) {
					priceLabel.setText("1.40");
				} else if (name.equalsIgnoreCase("Spoon")) {
					priceLabel.setText("3.40");
				}
				}catch(Exception e1) {
					outputArea.append("You didn't select a product!");
				}
				}
		});
		productPanel.add(selectButton);
		//label and textfield for price, qty and product name
		JLabel lblNewLabel_1 = new JLabel("");
		productPanel.add(lblNewLabel_1);

		JLabel lblNewLabel_5 = new JLabel("Price");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		productPanel.add(lblNewLabel_5);

		priceLabel = new JLabel("");
		priceLabel.setBackground(SystemColor.window);
		productPanel.add(priceLabel);

		JLabel lblNewLabel_6 = new JLabel("Quantity");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		productPanel.add(lblNewLabel_6);

		quantityTextField = new JTextField();
		productPanel.add(quantityTextField);
		quantityTextField.setColumns(10);

		JPanel panel = new JPanel();
		contentPane.add(panel);
		panel.setLayout(new BorderLayout(0, 0));

		JPanel outputPanel = new JPanel();
		outputPanel.setBorder(new TitledBorder(null, "Output", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.add(outputPanel, BorderLayout.CENTER);
		outputPanel.setLayout(new BorderLayout(0, 0));
		outputArea = new JTextArea();
		scroll = new JScrollPane(outputArea);
		outputPanel.add(scroll, BorderLayout.CENTER);
	}

}
