/*
 * Program description : 
 * This class will create a GUI that will create a new account and store the data
 * into a csv file for this purpose. 
 * Author: Geu THAO, Haley Roy, Samuel Xiong
 * Assignment: Final Project
 * Instructor : Zakaria Baani
 * Date: May, 6 2020
 * Class: CSCI 1082 
 */
package Gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;

import Class.CustomerAccountClass;
import Class.CustomerLogin;

import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class CreateNewAccountGui extends JFrame {

	private static final long serialVersionUID = 1L;
	//textfield that has to be available to the whole gui
	private JPanel contentPane;
	private JTextField firstNameTextField;
	private JTextField lastNameTextField;
	private JTextField addressTextField;
	private JTextField usernameTextField;
	private JTextField passwordTextField;
	private ArrayList<CustomerAccountClass> newCustomer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			//create a gui that's visible
			public void run() {
				try {
					CreateNewAccountGui frame = new CreateNewAccountGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	//The gui content
	public CreateNewAccountGui() {
		super("Create Account");
		newCustomer = new ArrayList<CustomerAccountClass>();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 578, 383);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		//panel that will contain the textarea and label to welcome the user data
		JPanel customerInfo = new JPanel();
		customerInfo
				.setBorder(new TitledBorder(null, "Information", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		contentPane.add(customerInfo, BorderLayout.NORTH);
		customerInfo.setLayout(new GridLayout(7, 2, 0, 10));

		//label and textfield for the first name
		JLabel firstName = new JLabel("First Name");
		customerInfo.add(firstName);

		firstNameTextField = new JTextField();
		customerInfo.add(firstNameTextField);
		firstNameTextField.setColumns(10);

		//label and textfield for the last name
		JLabel lastNameLabel = new JLabel("Last Name");
		customerInfo.add(lastNameLabel);

		lastNameTextField = new JTextField();
		customerInfo.add(lastNameTextField);
		lastNameTextField.setColumns(10);

		//label and textfield for the address
		JLabel address = new JLabel("Address");
		customerInfo.add(address);

		addressTextField = new JTextField();
		customerInfo.add(addressTextField);
		addressTextField.setColumns(10);

		//label and textfield for the username
		JLabel usernameLabel = new JLabel("Username");
		customerInfo.add(usernameLabel);

		usernameTextField = new JTextField();
		customerInfo.add(usernameTextField);
		usernameTextField.setColumns(10);

		//label and textfield for the password
		JLabel passwordLabel = new JLabel("Password");
		customerInfo.add(passwordLabel);

		passwordTextField = new JTextField();
		customerInfo.add(passwordTextField);
		passwordTextField.setColumns(10);

		//panel for the button
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Options", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		contentPane.add(panel, BorderLayout.CENTER);

		//create button
		JButton createAccount = new JButton("Create Account");
		createAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//get all information entered in the textfield
				String firstName = firstNameTextField.getText();
				String lastName = lastNameTextField.getText();
				String address = addressTextField.getText();
				String login = usernameTextField.getText();
				String password = passwordTextField.getText();

				try {
					//look if information are empty or not and return a message
					if (firstName.isEmpty() || lastName.isEmpty() || address.isEmpty() || login.isEmpty()
							|| password.isEmpty()) {
						JOptionPane.showMessageDialog(null, "Empty field!");
						return;
					} else {
						//create a new object and add it to the array
						CustomerLogin newCustomerLogin = new CustomerLogin(login, password);
						CustomerAccountClass newCustomerAccount = new CustomerAccountClass(firstName, lastName, address,
								newCustomerLogin);
						newCustomer.add(newCustomerAccount);
					}

				} catch (Exception e1) {
					// if file is not found, write error
					JOptionPane.showMessageDialog(null, "Error");
					return;
				}

				Writer newFile;

				try {
					//write the customer into a file
					newFile = new BufferedWriter(
							new OutputStreamWriter(new FileOutputStream("src\\customer.csv", true)));
					for (int i = 0; i < newCustomer.size(); i++) {
						// write each line in the file according
						CustomerAccountClass p = newCustomer.get(i);
						newFile.append(p.toString());

					}
					//if info are correct go back to login gui
					LoginGui logWindow = new LoginGui();
					logWindow.setVisible(true);
					dispose();
					newFile.close();

				} catch (Exception e1) {
					// if file is not found, write error
					JOptionPane.showMessageDialog(null, "Error file!");
					return;
				}
			}

		});
		panel.add(createAccount);
		
		//cancel button that will go to the login interface 
		JButton cancel = new JButton("Cancel");
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new LoginGui().setVisible(true);
				dispose();
			}
		});
		panel.add(cancel);
	}

}
