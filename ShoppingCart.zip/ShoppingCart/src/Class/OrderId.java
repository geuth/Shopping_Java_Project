/*
 * Program description : 
 * This class will be called when an order is finalized and return a random order number
 * There is also methods that will compare the product so they can be sorted according to the 
 * user option in the GUI.
 * Author: Geu THAO, Haley Roy, Samuel Xiong
 * Assignment: Final Project
 * Instructor : Zakaria Baani
 * Date: May, 6 2020
 * Class: CSCI 1082 
 */
package Class;

import java.util.ArrayList;
import java.util.Random;

public class OrderId {
	//variable that will take a random number 
		private long orderNum;
		private ArrayList<ProductType> productType;
		
		//will assign a random number for the product object created in the GUI
		public OrderId( ArrayList<ProductType> products) {
			super();
			this.orderNum = generateOrderNumber();
			this.productType = products;
		}

		//setter and getter for the random order number
		public long getOrderNum() {
			return orderNum;
		}

		public void setOrderNum(long orderNum) {
			this.orderNum = orderNum;
		}
		
		//generate random order number
		public long generateOrderNumber() {
			return 100000000L + new Random().nextInt(900000000);
		}

		//call the array of the cart
		public ArrayList<ProductType> getProductType() {
			return productType;
		}

		public void setProductType(ArrayList<ProductType> productType) {
			this.productType = productType;
		}
		
		//return the order number and the cart
		@Override
		public String toString() {
			return "Order Number :" + orderNum + ",\n" + productType ;
		}

	
		
}
