/*
 * Program description : 
 * This class will take the info (price and quantity and name)gotten from the other classes of product.
 * This class also calculate the total cost of the cart. It returns all info.
 * There is also methods that will compare the product so they can be sorted according to the 
 * user option in the GUI.
 * Author: Geu THAO, Haley Roy, Samuel Xiong
 * Assignment: Final Project
 * Instructor : Zakaria Baani
 * Date: May, 6 2020
 * Class: CSCI 1082 
 */
package Class;

//base class for the product class
public class ProductType{
	//variable for the product name, quantity, price and totalCost
	private String name;
	private int qty;
	private double price;
	private double totalCost;
	
	//constructor for the productType
	public ProductType(String name) {
		super();
		this.name = name;
	}

	//setter and getter for the name, qty, price, totalcost
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	
	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || (obj.getClass() != getClass()))
			return false;
		ProductType ProductType = (ProductType) obj;
		
		return this.name.equalsIgnoreCase(ProductType.name);
		
	}
	
	@Override
	public String toString() {
		return "\n"+name +", " ;
	}
	
	
}
