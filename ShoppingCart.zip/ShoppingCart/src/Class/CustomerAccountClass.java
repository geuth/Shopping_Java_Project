/*
 * Program description : 
 * This class will take the info (first name, last name, address and the object gotten from Customer login)
 * gotten from the GUI and return it into a String.
 * There is also methods that will compare the product so they can be sorted according to the 
 * user option in the GUI.
 * Author: Geu THAO, Haley Roy, Samuel Xiong
 * Assignment: Final Project
 * Instructor : Zakaria Baani
 * Date: May, 6 2020
 * Class: CSCI 1082 
 */
package Class;



public class CustomerAccountClass {
	//Variable for first name, last name, address and the object of customer login
	private String firstName;
	private String lastName;
	private String address;
	CustomerLogin customerLogin;
	
	//constructor that will take all variable and object
	public CustomerAccountClass(String firstName, String lastName, String address, CustomerLogin customerLogin) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.customerLogin = customerLogin;
	
	}
	
	//getter and setter for the variables
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	//get and set the customerLogin information from the class
	public CustomerLogin getCustomerLogin() {
		return customerLogin;
	}
	public void setCustomerLogin(CustomerLogin customerLogin) {
		this.customerLogin = customerLogin;
	}
	
	//return information
	public String infoCustomer() {
		return "First Name : " + firstName + "\nLast Name : "+ lastName+ "\n Address :" + address ;
	}
	
	//Return information with the login info
	@Override
	public String toString() {
		return firstName + ","+ lastName+ "," + address+ "," + customerLogin +"\n" ;
	}
	

	
}
