/*
 * Program description : 
 * This class will take the info (username and password)
 * gotten from the GUI and return it.
 * There is also methods that will compare the product so they can be sorted according to the 
 * user option in the GUI.
 * Author: Geu THAO, Haley Roy, Samuel Xiong
 * Assignment: Final Project
 * Instructor : Zakaria Baani
 * Date: May, 6 2020
 * Class: CSCI 1082 
 */
package Class;



public class CustomerLogin{
	
	//variable for the username and password
	private String username;
	private String password;
	
	//constructor that takes two parameters
	public CustomerLogin(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	
	//getter and setter for username and password
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	//return the data
	@Override
	public String toString() {
		return username + ","+  password;
	}
	

	
}
